"""The cave shuffle's enrolled screens and entries (OW-CAVE-02), shared by the
cave shuffle, the Armos shuffle and the recorder."""

from dataclasses import dataclass

from ...model.enums import Destination
from ...model.overworld import Overworld

# OW-APP-A1: the 72 enrolled screens, in list order (after OW-CAVE-02 step
# 2's exchange put the wooden-sword screen 119 last and 123 in its place).
ENROLLED_SCREENS = (
    1, 3, 4, 7, 10, 11, 12, 13, 14, 15, 16, 18, 19, 20, 22, 26, 28, 29, 30,
    31, 34, 35, 37, 38, 40, 45, 47, 51, 52, 55, 60, 61, 66, 68, 69, 70, 72,
    73, 74, 75, 77, 78, 81, 86, 91, 94, 99, 100, 102, 104, 106, 111, 112,
    116, 117, 118, 123, 120, 121, 124, 125, 5, 33, 39, 44, 71, 98, 103, 107,
    109, 113, 119
)
# OW-APP-A2: screens with a nonzero PRG0 code that never move.
FIXED_SCREENS = frozenset({0, 2, 6, 9, 17, 21, 24, 25, 27, 32, 41, 43, 48, 58, 83, 88,
                           96, 108, 110, 114})
FIXED_DUNGEON_DOORS = {5: 27, 6: 48, 7: 25, 8: 108, 9: 0}       # OW-ENTR-02
# OW-APP-A3: the screens the wooden-sword code may receive.
WOOD_SWORD_SCREENS = frozenset({4, 10, 11, 12, 14, 15, 26, 28, 31, 32, 33, 34, 36, 37, 52,
                                55, 60, 61, 68, 74, 78, 94, 100, 102, 111, 112, 116, 117, 119})
# OW-APP-A4: the reachability sets.
RAFT_SCREENS = frozenset({47, 69})
RECORDER_SCREENS = frozenset({66})
# OW-MIX-04 and OW-MIX-08: under a mixed overworld quest (C01 = 2) the recorder set is the eleven
# screens of FluteRoomSecretsOW, those whose entry became $80 included
MIXED_RECORDER_SCREENS = frozenset({66, 6, 41, 43, 48, 58, 60, 88, 96, 110, 114})
# Expanded Dungeon Locations under a 1st Quest overworld: 1Q7's lake and 2Q6's graveyard, the only
# recorder spots it can show (every other entry is off, so nothing else stands there). Under a 2nd
# Quest overworld it reads the eleven, which keep the second quest's other recorder secrets.
EXPANDED_RECORDER_SCREENS = frozenset({66, 48})
# Their entries (1Q7's, 2Q6's) and the pond's: the pool's recorder entries
EXPANDED_RECORDER_ENTRIES = frozenset({0, 4, 6})
# A FluteRoomSecretsOW entry that matches no screen (OW-MIX-04), and the pond entry ($3C), which every
# overworld quest keeps and Expanded Dungeon Locations always turns off
RECORDER_ENTRY_OFF = 0x80
POND_RECORDER_ENTRY = 6
LADDER_SCREENS = frozenset({24, 25})
BRACELET_SCREENS = frozenset({9, 17, 27, 29, 35, 73, 121})
BURNABLE_SCREENS = frozenset({40, 70, 71, 72, 75, 77, 81, 83, 86, 91, 98, 99, 104, 106, 107,
                              108, 109, 120})
# OW-APP-A6: the shortcut position index V of every screen.
SHORTCUT_POSITION_INDEX = (
    3, 2, 2, 1, 2, 2, 3, 2, 3, 2, 0, 0, 2, 2, 3, 3,
    3, 2, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2, 2, 0, 1, 2,
    2, 2, 0, 1, 2, 2, 3, 2, 3, 2, 2, 2, 1, 3, 2, 0,
    2, 2, 2, 2, 3, 2, 2, 0, 2, 0, 2, 2, 0, 1, 0, 2,
    2, 2, 0, 0, 1, 1, 3, 2, 2, 0, 2, 3, 2, 3, 2, 3,
    3, 2, 0, 3, 3, 2, 2, 2, 3, 0, 2, 3, 0, 3, 2, 3,
    3, 2, 3, 3, 3, 2, 3, 2, 3, 3, 2, 3, 2, 1, 2, 2,
    3, 3, 3, 3, 3, 2, 3, 3, 3, 2, 3, 0, 2, 2, 0, 2
)
DUNGEONS = range(1, 10)


@dataclass
class Entry:
    """One enrolled entry: a screen, the code it carries, its palette bits."""
    screen: int
    code: Destination
    inner_palette: int


@dataclass
class CaveShuffle:
    """What the walk decided, for the checks that follow it."""
    entries: list[Entry]
    armos_screen: int                # A: the formation's first screen

    def movable_screens(self, code: Destination) -> list[int]:
        """OW-SHOP-06's movable entrances of a code: enrolled entries
        carrying it, at their final screens."""
        return [entry.screen for entry in self.entries if entry.code == code]

    def entry_door(self, dungeon: int) -> int:
        """OW-ENTR-02: the entry that carries the dungeon's code."""
        doors = self.movable_screens(Destination(dungeon))
        assert len(doors) == 1, f"dungeon {dungeon}: {len(doors)} entry doors"
        return doors[0]


@dataclass
class OverworldResult:
    """The overworld passes' result: the staged model, written at ship, and the cave shuffle."""
    overworld: Overworld
    caves: CaveShuffle


def recorder_screens(overworld: Overworld) -> frozenset[int]:
    """OW-APP-A4's Recorder set for this overworld: screen 66, or under a mixed overworld quest,
    whose first quest reveals every listed secret, the eleven of OW-MIX-04 (OW-MIX-08). With the
    first quest revealing the listed secrets, the pond entry off and every entry off the pool off
    too, Expanded Dungeon Locations' two recorder spots under a 1st Quest overworld (ZORA's own: no
    overworld quest turns the pond entry off); under a 2nd it keeps the second quest's other
    entries, and reads the eleven."""
    if not overworld.recorder_reveals_listed_secrets_in_first_quest:
        return RECORDER_SCREENS
    entries = overworld.recorder_secret_screens
    if entries[POND_RECORDER_ENTRY] == RECORDER_ENTRY_OFF and all(
            screen == RECORDER_ENTRY_OFF for entry, screen in enumerate(entries)
            if entry not in EXPANDED_RECORDER_ENTRIES):
        return EXPANDED_RECORDER_SCREENS
    return MIXED_RECORDER_SCREENS
