from data.character import Character
from data.natural_magic import NaturalMagic
from data.commands import Commands
from data.menu_character_sprites import MenuCharacterSprites
from data.character_sprites import CharacterSprites
from data.character_palettes import CharacterPalettes
from data.party_battle_scripts import PartyBattleScripts
from data.structures import DataArray

import data.characters_asm as characters_asm

class Characters():
    CHARACTER_COUNT = 14   # 14 playable characters
    TERRA, LOCKE, CYAN, SHADOW, EDGAR, SABIN, CELES, STRAGO, RELM, SETZER, MOG, GAU, GOGO, UMARO = range(CHARACTER_COUNT)
    SOLDIER, IMP, GENERAL_LEO, BANON_DUNCAN, ESPER_TERRA, MERCHANT, GHOST, KEFKA = range(CHARACTER_COUNT, 22)

    # Moogle character indexes
    FIRST_MOOGLE = 0x12
    LAST_MOOGLE = 0x1B

    DEFAULT_NAME = ["TERRA", "LOCKE", "CYAN", "SHADOW", "EDGAR", "SABIN", "CELES", "STRAGO", "RELM", "SETZER", "MOG", "GAU", "GOGO", "UMARO"]

    INIT_DATA_START = 0x2d7ca0
    INIT_DATA_END = 0x2d821f
    INIT_DATA_SIZE = 22

    NAMES_START = 0x478c0
    NAMES_END = 0x47a3f
    NAME_SIZE = 6

    def __init__(self, rom, args, spells):
        self.rom = rom
        self.args = args
        self.start_levels = None    # per-character levels when -stlr is used
        self.exp_tables = None      # (default, capped) experience tables when -lc is used
        self.exp_cap = None         # battle experience cap when -lc is used

        self.init_data = DataArray(self.rom, self.INIT_DATA_START, self.INIT_DATA_END, self.INIT_DATA_SIZE)
        self.name_data = DataArray(self.rom, self.NAMES_START, self.NAMES_END, self.NAME_SIZE)

        self.characters = []
        for character_index in range(len(self.name_data)):
            character = Character(character_index, self.init_data[character_index], self.name_data[character_index])
            self.characters.append(character)

        self.playable = self.characters[:self.CHARACTER_COUNT]

        self.natural_magic = NaturalMagic(self.rom, self.args, self, spells)
        self.commands = Commands(self.characters)

        self.menu_character_sprites = MenuCharacterSprites(self.rom, self.args)
        self.character_sprites = CharacterSprites(self.rom, self.args)
        self.character_palettes = CharacterPalettes(self.rom, self.args, self.menu_character_sprites)

        self.battle_scripts = PartyBattleScripts(self.rom, self.args, self)

        self.available_characters = list(range(self.CHARACTER_COUNT))

        # path of characters required to unlock each character
        # e.g. self.character_paths[self.TERRA] = all characters required for terra (in order)
        self.character_paths = [[] for char_index in range(self.CHARACTER_COUNT)]

    def get_available_count(self):
        return len(self.available_characters)

    def set_unavailable(self, character):
        self.available_characters.remove(character)

    def get_random_available(self, exclude = None):
        if exclude is None:
            exclude = []

        import random
        possible_characters = [character_id for character_id in self.available_characters if character_id not in exclude]
        random_character = random.choice(possible_characters)
        self.set_unavailable(random_character)
        return random_character

    def set_character_path(self, character, required_character):
        if required_character is not None:
            self.character_paths[character].extend(self.character_paths[required_character])
            self.character_paths[character].append(required_character)

    def get_character_path(self, character):
        return self.character_paths[character]

    def mod_init_levels(self):
        # remove all variation in leveling, since we're controlling level directly
        for character in self.characters:
            character.init_level_factor = 0

        if self.args.start_level_random:
            import random
            self.start_levels = [random.randint(self.args.start_level_random_min,
                                                self.args.start_level_random_max)
                                 for _ in range(self.CHARACTER_COUNT)]
            characters_asm.set_random_starting_levels(self.start_levels, self.args.start_level)
        else:
            characters_asm.set_starting_level(self.args.start_level)

    def mod_level_cap(self):
        from data import level_cap
        default = [self.rom.get_short(level_cap.EXP_TABLE_START + 2 * index)
                   for index in range(level_cap.EXP_TABLE_COUNT)]
        if self.args.level_cap_hard is not None:
            # hard cap: vanilla table, battle experience capped at the total for the level
            capped = default
            self.exp_cap = level_cap.hard_cap_experience(default, self.args.level_cap_hard)
            characters_asm.set_battle_experience_cap(self.exp_cap)
            characters_asm.set_menu_level_cap(self.args.level_cap_hard)
        else:
            # soft cap: steeper table, vanilla battle cap
            capped = level_cap.capped_table(default, self.args.level_cap_mean, self.args.level_cap_width)
            for index, value in enumerate(capped):
                self.rom.set_short(level_cap.EXP_TABLE_START + 2 * index, value)
            self.exp_cap = level_cap.BATTLE_EXP_CAP
            # once experience stops at the battle cap no level can be gained: show
            # 0 experience to next level from the last reachable level on, as at 99
            highest = level_cap.highest_level(capped, self.exp_cap)
            if highest < 99:
                characters_asm.set_menu_level_cap(highest)
        self.exp_tables = (default, capped)

    def log_level_cap(self):
        from log import section, format_option
        from data import level_cap
        default, capped = self.exp_tables
        default_totals, capped_totals = level_cap.totals(default), level_cap.totals(capped)

        # every 5th level up to the last one battle can reach (experience stops at the cap)
        reachable = level_cap.highest_level(capped, self.exp_cap)
        entries = [format_option(f"Level {level}", f"{capped_totals[level - 1]:,} ({default_totals[level - 1]:,})")
                   for level in range(5, reachable + 1, 5)]
        if reachable % 5:
            entries.append(format_option(f"Level {reachable}",
                                         f"{capped_totals[reachable - 1]:,} ({default_totals[reachable - 1]:,})"))
        entries.append(format_option("Highest Level", reachable))
        entries.append(format_option("Experience Cap", f"{self.exp_cap:,}"))
        half = (len(entries) + 1) // 2
        section("Level Cap: Total Exp (Default)", entries[:half], entries[half:])

    def log_start_levels(self):
        from log import section, format_option
        entries = [format_option(self.DEFAULT_NAME[character].capitalize(), level)
                   for character, level in enumerate(self.start_levels)]
        half = (len(entries) + 1) // 2
        section("Starting Levels", entries[:half], entries[half:])

    def stats_random_percent(self):
        import random
        stats = ["init_extra_hp", "init_extra_mp", "init_vigor", "init_speed", "init_stamina", "init_magic",
                 "init_attack", "init_defense", "init_magic_defense", "init_evasion", "init_magic_evasion"]
        for character in self.characters:
            for stat in stats:
                stat_value = getattr(character, stat)
                if stat_value != 0:
                    character_stat_percent = random.randint(self.args.character_stat_random_percent_min,
                                                            self.args.character_stat_random_percent_max) / 100.0
                    value = int(stat_value * character_stat_percent)
                    setattr(character, stat, max(min(value, 255), 0))

    def get_characters_with_command(self, command_name):
        from constants.commands import name_id
        command_id = name_id[command_name]

        result = []
        for character in self.characters:
            if command_id in character.commands:
                result.append(character.id)
        return result

    def mod_names(self):
        for character_id, name in enumerate(self.args.names):
            self.characters[character_id].name = name

    def mod(self):
        if self.args.start_naked:
            for char in self.characters:
                char.clear_init_equip()

        if self.args.equipable_umaro:
            characters_asm.equipable_umaro(self.CHARACTER_COUNT)

        self.mod_init_levels()

        if self.args.level_cap_hard is not None or self.args.level_cap_mean is not None:
            self.mod_level_cap()

        if self.args.character_stat_random_percent:
            self.stats_random_percent()

        self.commands.mod()

        if self.args.character_names:
            self.mod_names()

        if self.args.steveify:
            for character in self.characters:
                character.name = self.args.steveify

        if self.args.original_name_display:
            characters_asm.show_original_names()

        self.natural_magic.mod()
        self.character_sprites.mod()
        self.character_palettes.mod()
        self.battle_scripts.mod()

    def write(self):
        if self.args.spoiler_log:
            self.commands.log()
            if self.start_levels:
                self.log_start_levels()
            if self.exp_tables:
                self.log_level_cap()

        for character_index in range(len(self.characters)):
            self.init_data[character_index] = self.characters[character_index].init_data()
            self.name_data[character_index] = self.characters[character_index].name_data()

        self.init_data.write()
        self.name_data.write()

        self.natural_magic.write()

        self.menu_character_sprites.write()
        self.character_sprites.write()
        self.character_palettes.write()
        self.battle_scripts.write()

    def print_character_paths(self):
        for char_index in range(self.CHARACTER_COUNT):
            path = self.get_character_path(char_index)
            for req_char_index in path:
                print(f"{self.DEFAULT_NAME[req_char_index]} -> ", end = '')
            print(f"{self.DEFAULT_NAME[char_index]}")

    def print(self):
        for char in self.characters:
            char.print()

    def get(self, character):
        for char in self.characters:
            if char.id == character:
                return char

    def get_by_name(self, name):
        for char in self.characters:
            if self.DEFAULT_NAME[char.id].lower() == name.lower():
                return char

    def get_name(self, character):
        return self.characters[character].name.rstrip('\0')

    def get_default_name(self, character):
        return self.DEFAULT_NAME[character]

    def get_sprite(self, character):
        return self.character_sprites.character_sprites[character].id

    def get_random_esper_item_sprite(self):
        sprites = [self.SOLDIER, self.IMP, self.MERCHANT, self.GHOST]

        import random
        return sprites[random.randrange(len(sprites))]

    def get_palette(self, character):
        return self.character_palettes.get(character)
