def markdown(s, **kw):
    return s
