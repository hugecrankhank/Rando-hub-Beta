def mark_safe(s):
    return s
