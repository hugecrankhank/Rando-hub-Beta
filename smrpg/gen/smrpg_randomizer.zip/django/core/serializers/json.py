import json

class DjangoJSONEncoder(json.JSONEncoder):
    pass
